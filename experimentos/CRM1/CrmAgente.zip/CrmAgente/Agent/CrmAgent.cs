using System.Text;
using System.Text.Json;
using CrmAgente.Models;
using CrmAgente.Services;

namespace CrmAgente.Agent;

// ============================================================
//  EL AGENTE
// ------------------------------------------------------------
//  Idea central a transmitir en clase:
//
//  El LLM NO consulta la base de datos. No sabe SQL, no ve las
//  tablas. Lo unico que hace es DECIDIR que herramienta llamar y
//  con que parametros. Nuestro codigo ejecuta la herramienta de
//  verdad (que por debajo usa EF Core) y le devuelve los datos al
//  modelo para que los redacte en lenguaje natural.
//
//  Resumen: el LLM razona, nuestro codigo ejecuta.
//
//  El flujo es un IDA Y VUELTA (round-trip):
//    1. Usuario pregunta en lenguaje natural
//    2. Mandamos pregunta + descripcion de herramientas al modelo
//    3. El modelo pide ejecutar una herramienta (no responde texto)
//    4. Nuestro codigo ejecuta el metodo real del CrmService
//    5. Le devolvemos el resultado al modelo
//    6. El modelo redacta la respuesta final en lenguaje natural
// ============================================================
public class CrmAgent
{
    private readonly CrmService crm;
    private readonly HttpClient http;
    private readonly string apiKey;

    private const string Modelo = "claude-sonnet-4-20250514";

    public CrmAgent(CrmService crm, IHttpClientFactory httpFactory, IConfiguration config)
    {
        this.crm = crm;
        this.http = httpFactory.CreateClient();
        // La API key se lee de configuracion / variable de entorno.
        // Nunca se hardcodea en el codigo.
        this.apiKey = config["ANTHROPIC_API_KEY"]
            ?? Environment.GetEnvironmentVariable("ANTHROPIC_API_KEY")
            ?? "";
    }

    public bool Configurado => !string.IsNullOrWhiteSpace(this.apiKey);

    // ---- Definicion de las herramientas que el modelo puede usar ----
    // Esto es un ESQUEMA (descripcion), no codigo. Le dice al LLM que
    // funciones existen, que hacen y que parametros aceptan. El modelo
    // usa estas descripciones para decidir cual llamar.
    private static object[] DefinirHerramientas() => new object[]
    {
        new
        {
            name = "buscar_oportunidades",
            description = "Busca oportunidades de venta filtrando por etapa del pipeline y/o monto minimo. Devuelve la lista con contacto, descripcion, monto y etapa.",
            input_schema = new
            {
                type = "object",
                properties = new
                {
                    etapa = new
                    {
                        type = "string",
                        @enum = new[] { "Prospecto", "Contactado", "Propuesta", "Negociacion", "Ganada", "Perdida" },
                        description = "Etapa del pipeline por la que filtrar (opcional)"
                    },
                    montoMinimo = new
                    {
                        type = "number",
                        description = "Monto minimo de la oportunidad (opcional)"
                    }
                }
            }
        }
    };

    // ---- Ejecuta la herramienta que el modelo pidio ----
    // Aca es donde nuestro codigo real corre. Tomamos el nombre de la
    // tool y sus parametros, y llamamos al metodo correspondiente del
    // CrmService (que usa EF Core y toca SQLite de verdad).
    private async Task<string> EjecutarHerramientaAsync(string nombre, JsonElement input)
    {
        if (nombre == "buscar_oportunidades")
        {
            Etapa? etapa = null;
            if (input.TryGetProperty("etapa", out var e) &&
                Enum.TryParse<Etapa>(e.GetString(), out var parsed))
            {
                etapa = parsed;
            }

            decimal? montoMinimo = null;
            if (input.TryGetProperty("montoMinimo", out var m))
            {
                montoMinimo = m.GetDecimal();
            }

            var resultados = await this.crm.BuscarOportunidadesAsync(etapa, montoMinimo);

            // Devolvemos los datos en un formato simple que el modelo
            // pueda leer y redactar.
            var datos = resultados.Select(o => new
            {
                contacto = o.Contacto?.Empresa ?? o.Contacto?.Nombre ?? "?",
                descripcion = o.Descripcion,
                monto = o.Monto,
                etapa = o.Etapa.ToString()
            });

            return JsonSerializer.Serialize(datos);
        }

        return "{\"error\":\"herramienta desconocida\"}";
    }

    // ---- El loop principal del agente ----
    public async Task<string> PreguntarAsync(string pregunta)
    {
        if (!this.Configurado)
        {
            return "El agente no esta configurado. Falta definir ANTHROPIC_API_KEY.";
        }

        // El historial de mensajes que se va construyendo en el round-trip.
        var mensajes = new List<object>
        {
            new { role = "user", content = pregunta }
        };

        // Hasta 5 vueltas: el modelo puede encadenar varias herramientas.
        for (var vuelta = 0; vuelta < 5; vuelta++)
        {
            var respuesta = await this.LlamarApiAsync(mensajes);

            using var doc = JsonDocument.Parse(respuesta);
            var root = doc.RootElement;

            if (!root.TryGetProperty("content", out var content))
            {
                return "Respuesta inesperada del modelo.";
            }

            // Reconstruimos el contenido del turno del asistente para el historial.
            var bloquesAsistente = new List<object>();
            var pedidosDeTool = new List<(string id, string nombre, JsonElement input)>();
            var textoFinal = new StringBuilder();

            foreach (var bloque in content.EnumerateArray())
            {
                var tipo = bloque.GetProperty("type").GetString();

                if (tipo == "text")
                {
                    var texto = bloque.GetProperty("text").GetString() ?? "";
                    textoFinal.Append(texto);
                    bloquesAsistente.Add(new { type = "text", text = texto });
                }
                else if (tipo == "tool_use")
                {
                    var id = bloque.GetProperty("id").GetString() ?? "";
                    var nombre = bloque.GetProperty("name").GetString() ?? "";
                    var input = bloque.GetProperty("input");

                    pedidosDeTool.Add((id, nombre, input));
                    bloquesAsistente.Add(new
                    {
                        type = "tool_use",
                        id,
                        name = nombre,
                        input = JsonSerializer.Deserialize<object>(input.GetRawText())
                    });
                }
            }

            // Si el modelo no pidio herramientas, ya tenemos la respuesta final.
            if (pedidosDeTool.Count == 0)
            {
                return textoFinal.ToString();
            }

            // Ejecutamos cada herramienta pedida y juntamos los resultados.
            mensajes.Add(new { role = "assistant", content = bloquesAsistente });

            var resultadosTool = new List<object>();
            foreach (var (id, nombre, input) in pedidosDeTool)
            {
                var resultado = await this.EjecutarHerramientaAsync(nombre, input);
                resultadosTool.Add(new
                {
                    type = "tool_result",
                    tool_use_id = id,
                    content = resultado
                });
            }

            // Le devolvemos los resultados al modelo para la siguiente vuelta.
            mensajes.Add(new { role = "user", content = resultadosTool });
        }

        return "El agente no pudo completar la consulta (demasiadas vueltas).";
    }

    // ---- Llamada HTTP cruda a la API de Anthropic ----
    private async Task<string> LlamarApiAsync(List<object> mensajes)
    {
        var cuerpo = new
        {
            model = Modelo,
            max_tokens = 1024,
            system = "Sos un asistente de un CRM. Cuando el usuario pregunta por " +
                     "oportunidades de venta, usa las herramientas disponibles para " +
                     "consultar los datos reales y luego responde de forma clara y " +
                     "concisa en espaniol rioplatense. Mostra montos con separador de miles.",
            tools = DefinirHerramientas(),
            messages = mensajes
        };

        var json = JsonSerializer.Serialize(cuerpo);
        using var req = new HttpRequestMessage(HttpMethod.Post, "https://api.anthropic.com/v1/messages");
        req.Headers.Add("x-api-key", this.apiKey);
        req.Headers.Add("anthropic-version", "2023-06-01");
        req.Content = new StringContent(json, Encoding.UTF8, "application/json");

        var resp = await this.http.SendAsync(req);
        return await resp.Content.ReadAsStringAsync();
    }
}
