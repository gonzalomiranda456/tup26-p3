using Microsoft.EntityFrameworkCore;
using CrmAgente.Data;
using CrmAgente.Models;

namespace CrmAgente.Services;

// Esta es la capa que concentra TODA la logica de negocio del CRM.
// Regla de oro de la arquitectura: tanto los componentes Blazor como
// el agente de IA consumen estos mismos metodos. No hay logica de
// negocio duplicada en la UI ni en el agente. Si esto funciona, el
// agente funciona; si no, no hay IA que lo salve.
public class CrmService
{
    private readonly CrmContext db;

    public CrmService(CrmContext db)
    {
        this.db = db;
    }

    // ---- Contactos ----

    public async Task<List<Contacto>> ListarContactosAsync(string? texto = null)
    {
        var query = this.db.Contactos.AsQueryable();

        if (!string.IsNullOrWhiteSpace(texto))
        {
            query = query.Where(c =>
                c.Nombre.Contains(texto) || c.Empresa.Contains(texto));
        }

        return await query.OrderBy(c => c.Nombre).ToListAsync();
    }

    public async Task<Contacto?> BuscarContactoAsync(string texto)
    {
        return await this.db.Contactos.FirstOrDefaultAsync(c =>
            c.Nombre.Contains(texto) || c.Empresa.Contains(texto));
    }

    // La ficha 360: trae el contacto CON sus oportunidades y actividades
    // en una sola consulta usando Include. Es el agregado completo que
    // describe el estado total de la relacion.
    public async Task<Contacto?> FichaCompletaAsync(int contactoId)
    {
        return await this.db.Contactos
            .Include(c => c.Oportunidades)
            .Include(c => c.Actividades)
            .FirstOrDefaultAsync(c => c.Id == contactoId);
    }

    public async Task<Contacto> CrearContactoAsync(string nombre, string empresa, string email, string telefono)
    {
        var contacto = new Contacto
        {
            Nombre = nombre,
            Empresa = empresa,
            Email = email,
            Telefono = telefono
        };

        this.db.Contactos.Add(contacto);
        await this.db.SaveChangesAsync();
        return contacto;
    }

    // ---- Actividades ----

    public async Task<Actividad> RegistrarActividadAsync(int contactoId, string tipo, string detalle)
    {
        var actividad = new Actividad
        {
            ContactoId = contactoId,
            Tipo = tipo,
            Detalle = detalle
        };

        this.db.Actividades.Add(actividad);
        await this.db.SaveChangesAsync();
        return actividad;
    }

    // ---- Oportunidades ----

    // Metodo de busqueda con filtros opcionales. Este es EXACTAMENTE el
    // metodo que el agente expone como herramienta. Notar como los
    // parametros opcionales permiten que el LLM combine filtros segun
    // lo que el usuario pregunte en lenguaje natural.
    public async Task<List<Oportunidad>> BuscarOportunidadesAsync(
        Etapa? etapa = null, decimal? montoMinimo = null)
    {
        var query = this.db.Oportunidades
            .Include(o => o.Contacto)
            .AsQueryable();

        if (etapa is not null)
        {
            query = query.Where(o => o.Etapa == etapa);
        }

        if (montoMinimo is not null)
        {
            query = query.Where(o => o.Monto >= montoMinimo);
        }

        return await query.OrderByDescending(o => o.Monto).ToListAsync();
    }

    public async Task<Oportunidad> CrearOportunidadAsync(int contactoId, string descripcion, decimal monto)
    {
        var oportunidad = new Oportunidad
        {
            ContactoId = contactoId,
            Descripcion = descripcion,
            Monto = monto,
            Etapa = Etapa.Prospecto
        };

        this.db.Oportunidades.Add(oportunidad);
        await this.db.SaveChangesAsync();
        return oportunidad;
    }

    public async Task<bool> MoverEtapaAsync(int oportunidadId, Etapa etapa)
    {
        var oportunidad = await this.db.Oportunidades.FindAsync(oportunidadId);
        if (oportunidad is null)
        {
            return false;
        }

        oportunidad.Etapa = etapa;
        await this.db.SaveChangesAsync();
        return true;
    }

    // Devuelve las oportunidades agrupadas por etapa: la data cruda del
    // tablero de pipeline.
    public async Task<List<Oportunidad>> ListarOportunidadesAsync()
    {
        return await this.db.Oportunidades
            .Include(o => o.Contacto)
            .ToListAsync();
    }
}
